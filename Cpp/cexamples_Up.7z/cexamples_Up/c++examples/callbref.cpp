#include <iostream>
using namespace std;

void fun1(int &x, int &y);

void fun1(int &x,int &y){ 
int temp;
temp=x;
x=y;
y=temp;

return;
}	

int main()
{
	 int a=100;
	 int b=200;
	 
	 cout << " the value of a before swap :" << a << endl;
	 cout << "the value of b before swap :" << b << endl;
	 
	 fun1(a,b);
	 cout << "value of a after swap "<< a << endl;
	 cout << " the value of b after swap "<<b << endl;
	 
	 return 0;
}
