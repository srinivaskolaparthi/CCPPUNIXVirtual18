#include <iostream>
#include <ext2.cpp>
	

#define HEADER_H
 using namespace std;
int count ;
extern void write_extern();
 
main() {
   count = 5;
   write_extern();
}

