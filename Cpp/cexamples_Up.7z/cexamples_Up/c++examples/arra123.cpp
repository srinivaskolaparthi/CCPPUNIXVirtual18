#include <iostream>
using namespace std;
int main()
{
   int mark[5]={10,23,44,56,67};
   
   cin >> mark[0];
   cout << mark[0];
   cin >> mark[1];
   cin >> mark[2];
   cin >> mark[3];
   cin >> mark[4];
   
   cout << mark[1] << "\n" << mark[2] <<"\n" << mark [3] << endl;
   
   return 0;
   
}
