#include <iostream>
using namespace std;

class Student{
	
	public:
	int eno;
	string ename;
	int sal;
	
};

int main(){
	
	Student stud;
	
	stud.eno=12;
	stud.ename="Hari haran";
	stud.sal=7000;
	
	cout << "Student number is : " << stud.eno << endl;
	cout << "Student name is : "  << stud.ename << endl;
	cout << " Student sal is :" << stud.sal << endl;
	
  	return 0;
}
