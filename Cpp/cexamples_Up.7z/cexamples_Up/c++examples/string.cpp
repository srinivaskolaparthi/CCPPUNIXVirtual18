// to read a word 

#include <iostream>
using namespace std;

int main()
{ 
   char str[100]="this is c++";
   
   cout << "enter the value of the string :";
  // cin.get(str,100);
   
   cout << str <<endl;
   return 0;
}
