#include <iostream>
using namespace std;
int main()
{
  cout<<"Welcome to C++ Programming"<<endl;
	return 0;
}
