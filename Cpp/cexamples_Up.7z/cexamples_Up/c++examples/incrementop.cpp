#include <iostream>
using namespace std;

int main()
{ 
    int a =10;
    int b;
    
    
    b=a++;
    
    
	cout << "what is the value of b:\t" << b <<  endl;
    
    cout << a<< endl;
    
    b=++a;
    
    cout << b << endl;
    
    
}
