#include<iostream>
using namespace std;

int main()
{
	 int x = 300;
	 //const int count =3;
	 
	 int *p;
	 
	 p=&x;
	 
	  cout << p << endl;
	  cout << *p << endl;
	 
	  p++;
	 
	 cout << p << endl;
	 
	
	return 0; 
	 
	
	 
	
}
