#include<iostream>
using namespace std;

class Add{
	
	int a;
	int b;
	int result;
	
	public :
		Add():a(40),b(50){
		}
		
		friend int addop(Add);
		
};

    int addop(Add obj){
    	obj.result = obj.a + obj.b;
    	return obj.result;
    	
    	
	}
	
	int main()
	{
		Add obj;
		
		cout << " the sum of the numbers is " << addop(obj);
		
	}
