#include <iostream>
using namespace std;

int main ()
{
	 //char str[7]={'O','r','a','c','l','e','\0'};
	 //char str[50];
	 string var;
	 
	 //cin >> str;
	 
	 //cin.get(str,50);
	 getline(cin,var);
	 cout << " the entered string value is : ";
	 //cout << str;
	 cout << var ;
}
