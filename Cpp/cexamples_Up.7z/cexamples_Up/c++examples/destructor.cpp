#include <iostream>
using namespace std;

// thsi is a program for destructor

class Student{
	public:
	int i;
	float f;
	
	
	Student(){
        cout << "default constructor ";	   
	}	
	
	~Student(){
		cout << "default destructor" ;
	}
};

int main()
{
	Student S1;
	return 0;
}

