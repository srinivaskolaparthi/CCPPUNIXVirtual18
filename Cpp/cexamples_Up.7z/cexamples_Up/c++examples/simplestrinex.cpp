#include <iostream>
using namespace std;

int main()
{
	 char var[6]={'O','r','a','c','l','e'};
	 
	 	 
	 cout << "the character values are :";
	 cout << var << endl;
	 
	 return 0;
	 
}

