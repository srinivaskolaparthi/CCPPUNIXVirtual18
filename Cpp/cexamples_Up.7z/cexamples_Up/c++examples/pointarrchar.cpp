#include <iostream>
#include <string>

 
using namespace std;
 const int var = 2;
 
int main () {
   const char *names[2] = {
       "Zara Ali",
      "Hina Ali" }
;  
   

   for (int i = 0; i < var; i++) {
      cout << "Value of names[" << i << "] = ";
      cout << names[i] << endl;
}
   return 0;
}


