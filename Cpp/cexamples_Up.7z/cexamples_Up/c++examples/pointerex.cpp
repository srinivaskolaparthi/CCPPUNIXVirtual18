#include<iostream>
using namespace std;

int main()
{
	int a=20;
	
	int  *s=NULL;
	
	cout << s << endl;
	s=&a;
	
	cout << a << endl ;// value of a 
	cout << s << "\t" << &a << endl; // print the address stored in s pointer variable
	cout <<  *s << endl; // access the value of address available in pointer
	
	return 0;
	
}
