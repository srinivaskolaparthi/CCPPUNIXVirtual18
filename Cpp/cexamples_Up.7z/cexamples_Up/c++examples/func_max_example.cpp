#include <iostream>
using namespace std;

int max(int x,int y ); // function prototype

int main(){
	int a =40;
	int b =70;
	int rest;
	
	rest = max(a,b); // function call  
	cout << rest << endl;
	return 0;
		
} 

int max(int x, int y){
int c ;
  if ( x > y) 
  c=x;
  
else 
  c = y;
 
 return c;}
  



