#include <iostream>
using namespace std;

class shape{
	protected :
	float width,height;
	public:
				
	void setarea(float w,float h){
              width=w;
              height=h;
 		
	}	
	
		
		
};

class rectangle:public shape{
	public:
		double getarea(){
			 return height * width;
		}
};
class triangle : public shape{
	public:
		double getarea(){
			 return (height * width/2);
		}
};

int main()
{
	  rectangle r1;
	  triangle t1;
	  r1.setarea(2.4,5.5);
	  t1.setarea(6.2,3);
	  r1.getarea();
	  r1.getarea();
	  cout << r1.getarea() << "\t" << t1.getarea() << endl;
	  return 0;
}
