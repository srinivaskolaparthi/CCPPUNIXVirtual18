#include<iostream>
using namespace std;

class  Student{
	
	private :
		
		int eno;
		string ename;
		int sal;
		
	public :
		
		Student() : eno(102),ename("Steve"),sal(300){}

       /* void getdetails(){        	
        		cout << "Enter the details ";
        		cin >> eno >>ename >> sal;
        		
			}	*/
			
			void display(){
				cout << eno << ename <<sal;
			}	
	};
	
	int main() {
		Student s1;
		
	//	s1.getdetails();
		s1.display();
		s1.eno=567; // private member cannot be accessed outside the class
		
		
		return 0;
		}
