#include <iostream>
using namespace std;

int sum(int , int );

int main ()
{
	 int a=44;
	 int b=56;
	 int total;
	 
	 total=sum(a,b);
	 cout << "the total value is " << total << endl;
	 	 
 	 
}

int sum(int x ,int y ){
	
	int g;
	g= x + y;
	return g;
}
