#include <iostream>  
#include <fstream>  
using namespace std;  
int main () {  
  ofstream filestream("testout.txt");  
  if (filestream.is_open())  
  {  
    filestream << "Welcome to c++.\n";  
    filestream << "This a new learning.\n";  
    filestream.close();  
  }  
  else cout <<"File opening fails.";  
  return 0;  
}  
