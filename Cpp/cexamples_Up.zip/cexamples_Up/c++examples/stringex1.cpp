#include <iostream>

using namespace std;

int main()
{
  //char var[50];
  string str;
  //cin >> var;
  cout << " the entered string is ";
  
 // cin.get(var,50);
  
  getline(cin,str);
  
    cout << str <<endl;
  //cout << var ;
   
}
