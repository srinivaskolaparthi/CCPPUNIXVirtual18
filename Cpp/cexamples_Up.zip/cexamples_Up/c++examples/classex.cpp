#include<iostream>
using namespace std;

class Stud{
	public:
	int no;
	string name;
	
	void getdet(int id,string ename){
		no=id;
		name=ename;
	}
	
	void display()
	{
		 cout << no << "\t" << name << endl;
	}
}; 

int main()
{
      Stud obj;
     //obj.no=10;
	 //obj.name="hari"; 
	 
	 obj.getdet(20,"Hema");
	 obj.display();
//	 cout << obj.no << obj.name << endl;
	 return 0;
}

