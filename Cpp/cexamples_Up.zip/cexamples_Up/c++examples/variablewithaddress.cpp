#include<iostream>
using namespace std;

int main()
{
	int a=20;
	char b[20]="hello";
	
	cout << a << endl;
	cout << &a << endl;
	
	cout << b << "\t" << &b << endl;
	return 0;
	
}
