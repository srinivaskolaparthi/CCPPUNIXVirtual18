#include <iostream>  
#include <fstream>
using namespace std;  
int main () {  
   char input[75];  
   
   //open a file in write mode
   ofstream os;  
   os.open("testout.txt");  
   cout <<"Writing to a text file:" << endl;  
   cout << "Please Enter your name: ";   
   cin.getline(input, 100);  
   
   //write input data to file
   
   os << input << endl;  
   cout << "Please Enter your age: ";   
   cin >> input;  
   cin.ignore();  
   // again write input data into the file
   
   os << input << endl;  
   
   //close the opened file 
   
   os.close();  
   
   //open a file in read mode 
   ifstream is;   
   string line;  
   is.open("testout.txt");   
   
   //write the data on the screen
   cout << "Reading from a text file:" << endl;   
   while (getline (is,line))  
   {  
   cout << line << endl;  
   }      
   is.close();  
   return 0;
}
