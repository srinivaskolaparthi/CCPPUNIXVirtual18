#include<iostream>
using namespace std;
class Cube1
{

public:
	int side;
Cube1()
 {  
  side=6;  
 }
};

int main()
{
Cube1 c;
cout << c.side;

}
