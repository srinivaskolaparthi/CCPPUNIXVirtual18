#include<iostream>
using namespace std;

int main()
{
	 int age;
	 cout << "enter your age :";
	 cin >> age;
	 cout << " the age is "<< age<<endl;
	 
}
