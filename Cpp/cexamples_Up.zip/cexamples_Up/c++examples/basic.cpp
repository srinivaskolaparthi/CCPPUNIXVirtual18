#include <iostream>
using namespace std;

int main()
{
	int a =45;
	//float b= 3.4;
	int c;
	//float d;
	
	c= (int)b;
	d=(float)a;
	cout << c << endl;
	cout << d << endl;
	return 0;
	
}
