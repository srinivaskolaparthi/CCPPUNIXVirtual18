#include <iostream>
using namespace std;

main(){
cout << "Hello";
return 0;
}
