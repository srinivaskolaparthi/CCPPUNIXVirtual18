#include <iostream>

using namespace std;

class Employee {
	
	public :
		
		Employee()
		{
			cout << "default Constructor ";
		}
};


int main(){
	
	Employee E1;
	Employee E2;
	return 0;
}
