#include <iostream>
using namespace std;

class Student{
	
	public:
	int eno;
	string ename;
	int sal;
	
	void getdetails(int n,string name , int salary){
		eno=n;
		ename=name;
		sal=salary;
		
	}
	
	void display(){
		cout << "the employee id is " << eno << "\n" << "the name is "<< ename <<endl;
		
	}
};
int main(){
	
	Student stud1;
	Student stud2;
	
	stud1.getdetails(10,"Julie",1200);
	stud2.getdetails(20,"Ram",5000);
	stud1.display();
	stud2.display();
	
 	return 0;
}
