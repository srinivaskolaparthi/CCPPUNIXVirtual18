#include <iostream>  
using namespace std;  
int main( ) {  
   char ary[] = "This is C++ programming ";  
   cout << "Value of ary is: " << ary << endl;  
}  
