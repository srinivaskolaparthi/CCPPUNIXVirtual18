#include<iostream>
using namespace std;

int main()
{
    int a,b;
    int c;
    
    a=10;
    b=20;
    
    c=a+b;
    
    cout << "the result is " << c<< endl;
    return 0;
}

