#include <iostream>
using namespace std;

const int MAX=3;

int main()
{
	int var[MAX]={100,200,300};
	
	int *p;
	
	p=var;
	
	for (int i=0;i<MAX;i++)
	{
		  cout << " Address of var [" << i << "]=";
		  cout << p << endl;
		  
		   cout << " Address of var [" << i << "]=";
		  cout << *p << endl;
		  
		  p++;
		  
	}
	
	return 0;
}


