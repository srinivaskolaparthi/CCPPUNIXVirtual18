#include <iostream>
using namespace std;

main(){
	int a =30;
	int b=40;
	if (a==50)
	cout << a<<endl;
	else if (b==40)
	cout << " b is 40" <<endl;
	else
	cout << "it is c "<<endl;
	
}

