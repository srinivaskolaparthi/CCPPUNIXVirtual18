#include<iostream>
#include<conio.h>

inline void show()
{ 
  cout<<"Hello world";
}

int main()
{
 show();  // Call it like a normal function
}
