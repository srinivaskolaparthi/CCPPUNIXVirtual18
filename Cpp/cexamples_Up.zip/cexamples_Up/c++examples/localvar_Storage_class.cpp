#include <iostream>
using namespace std;
int c =12;
void test();

int main(){
//int x =5; 

test();
//cout << x << "\t" << c << endl;
test();
return 0;

}

void test(){
//	int var = 34;
	static int var2 =0;
//	cout <<var2 << endl;
	var2 ++;
	cout << var2 << endl;
//	cout << var << "\t" << c << endl;
//	cout << x << endl;
}
