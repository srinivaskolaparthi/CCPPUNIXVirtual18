#include<iostream>
using namespace std;

class shape{
	public:
		float height;
		float width;
		
		void setarea(float h ,float w){
			height=h;
			width=w;
		}

        
};

class Rectangle:public shape{
           public:
            float getarea(){
        	return height * width ;
		}	
	     
};

int main() {
	
	Rectangle obj;
	obj.setarea(1.2,3);
	obj.getarea();
	cout << obj.getarea() << endl;
}
