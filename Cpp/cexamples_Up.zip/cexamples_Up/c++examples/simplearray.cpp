#include <iostream>
using namespace std;

int main(){
	int num[]={12,45,56,76,88};
	
	for (int i=0;i<5;i++){
		cout << num[i]<< "\n";
	}
}
