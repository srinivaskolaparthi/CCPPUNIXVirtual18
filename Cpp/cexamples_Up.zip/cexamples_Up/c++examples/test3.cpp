#include<iostream>
#incldue<conio.h>
using namespace std;

//main() is the place where the program begin

main()
{
	cout<< "Hello world";
	getch();
	return 0;
}
