//library function 

#include <iostream>
#include<cmath>
using namespace std;

int main(){
 double num=9;
 double res;
  res=sqrt(num);
   cout << "square root value is :"<<res<<endl;
 return 0;
}


