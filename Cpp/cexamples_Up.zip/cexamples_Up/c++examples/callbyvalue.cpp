#include <iostream>
using namespace std;

void  fun(int a);

int main(){
 
 int  a = 32;
 //int res;
 fun(a);
 cout << a << endl;
 return 0;
  
}

void fun(int a)
{ int c =40;


}
