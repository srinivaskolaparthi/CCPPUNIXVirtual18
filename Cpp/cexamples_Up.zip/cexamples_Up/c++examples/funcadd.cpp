#include<iostream>
using namespace std;

int add(int num1,int num2);

int main(){
	int a =20;
	int b=30;
	int c;
	
	c= add(a,b);
	cout << c << endl;
	
	
}

int add(int x , int y)
{
  int sum ;
  sum = x + y;
  return sum;
}

