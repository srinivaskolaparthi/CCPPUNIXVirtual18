#include <iostream>
using namespace std;
//Parameterrised Constructor

class Student {

   public:	
	int id; // data member 
	string name ;
	int marks;
	
			
		Student(int no,string ename,int score){	 //parameterised constructor
		
		id=no;
		name=ename;
		marks=score;
		
		}
		
		void display(){      // member function
			cout << "student no" << id << endl;
			cout << " student name "<< name << endl;
			
		}
};
		int main(){
			
			   Student s=Student(123,"raj",78); //this step is mandatory  - creating an object of type employee
			   Student s1 = Student(140,"jack",300);
			   s1.display();  
			   s.display();
			   
			   
			   return 0;
		}

