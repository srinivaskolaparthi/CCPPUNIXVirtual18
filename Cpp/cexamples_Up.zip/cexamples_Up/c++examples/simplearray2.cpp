#include <iostream>
using namespace std;

int main()
{
	int var[5]={11,32,45,66,33};
	
	for (int i:var){
		cout << i << "\n";
		
	}
}
