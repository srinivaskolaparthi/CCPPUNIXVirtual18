#include <iostream>
using namespace std;

class Add{
      int x;
	  int y;
	  
 	public :
 		static int count;		
		
		Add(int a=35,int b=22){
			
			cout << "constructor called" << endl;
		    x=a;
			y=b;	
			count++;
		}
		
		
		
		int getresult(){
			return x + y;
			
		}
		
};

int Add :: count =0; // Initialise static member of a class

int main(){
     int tot;	
	Add a1(13,23);
    tot=a1.getresult();
    cout << tot << endl;
	
	Add b1(90,60);
	tot=b1.getresult();
	cout << tot << endl;
	cout << "the total count is " << Add :: count<<  endl;
	
}

